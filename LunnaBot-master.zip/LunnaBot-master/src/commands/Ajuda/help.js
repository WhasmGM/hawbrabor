module.exports = (client, message, args) => client.commands.ajuda(client, message, args);
