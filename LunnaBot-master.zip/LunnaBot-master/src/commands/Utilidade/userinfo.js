module.exports = (client, message) => client.commands.perfil(client, message);
