module.exports = async (client, message, args) => {
    client.commands.banzinho(client, message, args);
};
