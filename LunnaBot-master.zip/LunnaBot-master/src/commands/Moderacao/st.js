module.exports = (client, message, args) => {
    client.commands.settopic(client, message, args);
};
